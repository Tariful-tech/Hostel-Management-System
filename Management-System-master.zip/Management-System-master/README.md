# Hostel-Management-System
This is a prototype of the hostel management system which is developed for the university hostel of Bangladesh Army International University of Science & Technology and was also a part of the System Analysis Design & Development course. There are two other contributors who also contributed to this project. This is basically a web-based raw PHP project.
