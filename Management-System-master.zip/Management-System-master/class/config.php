<?php
define('DB_HOST','localhost');//sql211.epizy.com
define('DB_NAME','baiust_hall');//epiz_23793784_baiust_hall
define('DB_USER','root');//epiz_23793784
define('DB_PASSWORD','');//bVVS9kLvr
 ?>
