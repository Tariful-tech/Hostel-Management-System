<?php
//sql211.epizy.com
//epiz_23793784_baiust_hall
//epiz_23793784
//bVVS9kLvr
$connect=mysqli_connect("localhost","root","");
if($connect){
  $dbselect=mysqli_select_db($connect,"baiust_hall");
  if($dbselect){

  }
}
 ?>
