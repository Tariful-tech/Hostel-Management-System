<div class="w-80">
      <div class="container mt-4">
        <table class="table table-hover">
          <thead class="thead-light">
            <tr>
              <th scope="col">Building No</th>
              <th scope="col">Room No</th>
              <th scope="col">Bed No</th>
            </tr>
          </thead>
            <tbody>
              <tr>
                <td><?php echo $data2['building_no']; ?></td>
                <td><?php echo $data2['room_no']; ?></td>
                <td><?php echo $data2['bed_no']; ?></td>
              </tr>
            </tbody>
        </table>

      </div>

</div>
